#!/usr/bin/env python3
        
def get_float(prompt, low, high):
    is_valid= False
    while True:
        number = float(input(prompt))
        if number > low and number <= high:  
            is_valid= True
            return number
        else:
            print("Entry must be greater than ", low, "and less than or equal to ", high)

def get_int(prompt, low, high):
    is_valid= False
    while True:
        number = int(input(prompt))
        if number > low and number <= high:  
            is_valid= True
            return number
        else:
            print("Entry must be greater than ", low, "and less than or equal to ", high)


def main():
    choice = "y"
    while choice.lower() == "y":
        # get input from the user
        float_test = get_float("Enter number:\t", 0, 1000)
        print(float_test, " is a valid float entry")
        int_test = get_int("Enter whole number:\t\t", 0, 50 )
        print(int_test, " is a valid int entry")
        # see if the user wants to continue
        choice = input("Continue? (y/n): ")
        print()

    print("Bye!")
    
if __name__ == "__main__":
    main()
